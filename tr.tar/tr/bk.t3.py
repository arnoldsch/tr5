import os,sys
from tensorflow.keras.layers import Bidirectional, Concatenate, Permute, Dot, Input, LSTM, Multiply
from tensorflow.keras.layers import RepeatVector, Dense, Activation, Lambda,TimeDistributed
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import load_model, Model
import tensorflow.keras.backend as K
import numpy as np

import matplotlib.pyplot as plt
import matplotlib.colors as mcolors




def split_train_test(X,Y,seed=42):
    idx_s = np.arange(X.shape[0])
    np.random.seed(seed)
    np.random.shuffle(idx_s)
    n = int(len(X)*0.8)
    idx_train = idx_s[:n]
    idx_test = idx_s[n:]
    
    X_train = X[idx_train]
    Y_train = Y[idx_train]
    X_test = X[idx_test]
    Y_test = Y[idx_test]

    return X_train,Y_train,X_test,Y_test


def init_ds0(m,Tx):
    np.random.seed(42)
    X,Y=[],[]
    X  = np.random.randint(0,100,size=(m,Tx))
    X = X.reshape((*X.shape,1))
    Y = X.sum(axis=1)

    return X,Y


def init_ds1(m,Tx):
    X  = np.random.randint(0,100,size=(m,Tx,3))
    Y = X.sum(axis=2)
    Y = np.reshape(Y,(*Y.shape,1))

    return X,Y


def init_ds2(m,Tx,Ty):

    ns0 = Tx+Ty
    xx = np.linspace(0,700*m,ns0*m)
    x = np.sin(xx*np.pi/180)

    X,Y=[],[]
    for i in range(m):
        x_ = x[i*ns0:(i+1)*ns0]
        X.append(x_[:Tx])
        Y.append(x_[Tx:])


    X = np.reshape(X,(*np.shape(X),1))
    Y = np.reshape(Y,(*np.shape(Y),1))


    def plot_tst():
        for j in range(5):
            xx = np.arange(ns0)
            plt.plot(xx[:Tx],X[j].flatten(),'o-')
            plt.plot(xx[Tx:],Y[j].flatten(),'o-')

        plt.show()

    #plot_tst()
    #sys.exit(0)
    return X,Y






def init_ds3(m,Tx,Ty):

    ns0 = Tx+Ty

    x = np.zeros(ns0*m)
    for f in [100,1200]:
        xx = np.linspace(0,f*5*m,ns0*m)
        x += np.sin(xx*np.pi/180)

    X,Y=[],[]
    for i in range(m):
        x_ = x[i*ns0:(i+1)*ns0]
        X.append(x_[:Tx])
        Y.append(x_[Tx:])


    X = np.reshape(X,(*np.shape(X),1))
    Y = np.reshape(Y,(*np.shape(Y),1))


    def plot_tst():
        for j in range(1):
            xx = np.arange(ns0)
            plt.plot(xx[:Tx],X[j].flatten(),'o-')
            plt.plot(xx[Tx:],Y[j].flatten(),'o-')

        plt.show()

    #plot_tst()
    #sys.exit(0)
    return X,Y
















def f0():
    m = 2000
    Tx = 5
    X,Y = init_ds0(m,Tx)
    X_train,Y_train,X_test,Y_test = split_train_test(X,Y)
    print('ds dims:',X.shape,Y.shape)



    uX = Input(shape=(Tx,1))
    n_a0 = 64
    n_a1 = 64
    l0 = LSTM(n_a0,return_sequences=False)(uX)
    l00 = RepeatVector(1)(l0)
    #l1 = LSTM(n_a1,return_sequences=False,input_shape=(Tx,1))(l00)
    l1 = LSTM(n_a1,return_sequences=False,input_shape=(1,1))(l00)
    l2 = Dense(1)(l1)


    model = Model(inputs=uX,outputs=l2)
    model.compile(loss='mse', optimizer='adam')

    model.fit(X_train,Y_train,epochs=300)

    y_pred = model.predict(X_test)


    plt.scatter(y_pred.flatten(),Y_test.flatten())
    plt.show()

def f1():
    m = 2000
    Tx = 20
    n = 3

    X,Y = init_ds1(m,Tx)
    X_train,Y_train,X_test,Y_test = split_train_test(X,Y)
    print('======================= ds dims:',X.shape,Y.shape)
    print('======================= ds dims:',X_train.shape,Y_train.shape)

    #X_ = X[0]
    #for i in range(20):
    #    print(X_[i,0],X_[i,1],X_[i,2],Y[0,i])

    Ty = Tx
    
    uX = Input(shape=(Tx,n))
    n_a0 = 64
    n_a1 = 64
    l0 = LSTM(n_a0,return_sequences=True)(uX)
    #l00 = RepeatVector(Tx)(l0)
    #l1 = LSTM(n_a1,return_sequences=True)(l00)

    l1 = TimeDistributed(Dense(1), input_shape=(Tx, n_a0))(l0)

    model = Model(inputs=uX,outputs=l1)
    #print(model.predict(X_test).shape)
    model.compile(loss='mse', optimizer='adam')

    model.fit(X_train,Y_train,epochs=200)
    y_pred = model.predict(X_test)



    def plot_tst():
        plt.scatter(y_pred.flatten(),Y_test.flatten())
        plt.show()

    plot_tst()
    

def f2():
    m = 2000
    Tx = 20
    Ty = 5
    n = 1

    X,Y = init_ds2(m,Tx,Ty)
    X_train,Y_train,X_test,Y_test = split_train_test(X,Y)
    print('======================= ds dims:',X.shape,Y.shape)

    uX = Input(shape=(Tx,n))

    n_a0 = 64
    n_a1 = 64

    l0, state_h, state_c = LSTM(n_a0,return_state=True)(uX)
    encoder_states = [state_h, state_c]

    l1 = Dense(100, activation='relu')(l0)
    l2 = Dense(Ty)(l1)

    model = Model(inputs=uX,outputs=l2)
    model.compile(loss='mse', optimizer='adam')



    #uX2 = Input(shape=(None,Ty))

    #l1,_,_ = LSTM(n_a1,return_sequences=True,return_state=True)(uX2,initial_state=encoder_states)
    #l2 = TimeDistributed(Dense(1), input_shape=(Ty, n_a1))(l1)

    #model = Model(inputs=[uX,uX2],outputs=l2)
    #model.compile(loss='mse', optimizer='adam')

    model.fit(X_train,Y_train[:,:,0],epochs=200)
    y_pred = model.predict(X_test)
    y_pred = y_pred.reshape((*y_pred.shape,1))


    def plot_tst():
        ns0 = Tx+Ty

        for j in range(5):
            xx = np.arange(ns0)
            plt.plot(xx[:Tx],X[j].flatten(),'o-')
            plt.plot(xx[Tx:],Y[j].flatten(),'o-')
            plt.plot(xx[Tx:],y_pred[j].flatten(),'o-')
        plt.show()


    plot_tst()


def f3():
    m = 10000
    Tx = 30
    Ty = 5
    n = 1

    X,Y = init_ds2(m,Tx,Ty)
    X_train,Y_train,X_test,Y_test = split_train_test(X,Y)
    print('======================= ds dims:',X.shape,Y.shape)

    n_a0 = 100
    n_a1 = 100

    uX = Input(shape=(Tx,n))
    encoder = LSTM(n_a0,return_state=True)

    l0, state_h, state_c = encoder(uX)
    encoder_states = [state_h, state_c]


    uX2 = Input(shape=(Ty,n))


    decoder_lstm = LSTM(n_a1,return_sequences=True,
            return_state=True)
    l1,dec_h,dec_c = decoder_lstm(uX2,initial_state=encoder_states)
    dec_state_out = [dec_h,dec_c]


    decoder_dense = TimeDistributed(Dense(1), input_shape=(Ty, n_a1))
    l2 = decoder_dense(l1)

    model = Model(inputs=[uX,uX2],outputs=l2)
    model.compile(loss='mse', optimizer='adam')
    


    dec_x_train = np.zeros((len(Y_train),Ty,n))
    dec_x_train[:,0,:] = np.copy(X_train[:,-1,:])
    dec_x_train[:,1:,:] = np.copy(Y_train[:,:-1,:])

    #model.fit([X_train,dec_x_train],Y_train,epochs=100)

    y_pred = model.predict([X_test,dec_x0])

    sys.exit(0)

    m0 = Model(inputs=[uX],outputs=encoder_states)
    m1 = Model(inputs=[uX2],outputs=l2)
    state = m0.predict(X_test)
    yhat,h_,c_ = m1.predict([yhat]+state)

    print(model.summary())


    #encode_model = Model(uX,encoder_states)

    #print(encode_model.summary())

    #decoder_state_input_h = Input(shape=(n_a1,))
    #decoder_state_input_c = Input(shape=(n_a1,))
    #decoder_states_inputs = [decoder_state_input_h, decoder_state_input_c]

    #decoder_outputs, state_h, state_c = decoder_lstm(uX2, initial_state=decoder_states_inputs)
    #decoder_states = [state_h, state_c]

    #decoder_outputs = decoder_dense(l2)
    #decoder_model = Model([uX2] + decoder_states_inputs, [decoder_outputs] + decoder_states)

    #state = infenc.predict(X_test)

    #yhat_ = np.zeros((1,1,1))
    #yhat, h, c = infdec.predict([yhat_] + state)

    #print(yhat)



    #output = []
    #for t in range(Ty):
    #    # predict next char
    #    yhat, h, c = infdec.predict([yhat_] + state)
    #    # store prediction
    #    output.append(yhat[0,0,:])
    #    # update state
    #    state = [h, c]
    #    # update target sequence
    #    yhat_ = yhat

    #output = array(output)



    #y_pred = model_inf.predict(X_test)
    y_pred = y_pred.reshape((*y_pred.shape,1))



    def plot_tst():
        ns0 = Tx+Ty

        for j in range(2):
            xx = np.arange(ns0)
            plt.plot(xx[:Tx],X[j].flatten(),'o-')
            plt.plot(xx[Tx:],Y[j].flatten(),'o-')
            plt.plot(xx[Tx:],y_pred[j].flatten(),'o-')
        plt.show()

    plot_tst()


def f4():
    n_epochs=100
    m = 2000
    Tx = 20
    Ty = 20
    n = 1

    X,Y = init_ds2(m,Tx,Ty)
    X_train,Y_train,X_test,Y_test = split_train_test(X,Y)
    print('======================= ds dims:',X.shape,Y.shape)

    n_a0 = 100
    n_a1 = 100

    uX = Input(shape=(None,n))
    encoder = LSTM(n_a0,return_state=True)

    l0, state_h, state_c = encoder(uX)
    encoder_states = [state_h, state_c]





    uX2 = Input(shape=(None,n))

    decoder_lstm = LSTM(n_a1,return_sequences=True,
            return_state=True)
    l2,dec_h,dec_c = decoder_lstm(uX2,initial_state=encoder_states)

    decoder_dense = Dense(1)
    l2 = decoder_dense(l2)
    model = Model(inputs=[uX,uX2],outputs=l2)
    model.compile(loss='mse', optimizer='adam')


    #y = model.predict([np.zeros((1,1,1)),np.zeros((1,1,1))])
    #print(y.shape)
    #sys.exit(0)


    dec_x_train = np.zeros((len(Y_train),Ty,n))
    dec_x_train[:,0,:] = np.copy(X_train[:,-1,:])
    dec_x_train[:,1:,:] = np.copy(Y_train[:,:-1,:])

    model.fit([X_train,dec_x_train],Y_train,epochs=n_epochs)

    #y_pred = model.predict([X_test,dec_x0])

    encode_model = Model(uX,encoder_states)
    #y = encode_model.predict(np.zeros((1,1,1)))
    #print(y[0].shape,y[1].shape)
    #sys.exit(0)
    #print(encode_model.summary())

    decoder_state_input_h = Input(shape=(n_a1,))
    decoder_state_input_c = Input(shape=(n_a1,))
    decoder_states_inputs = [decoder_state_input_h, decoder_state_input_c]

    l2, state_h, state_c = decoder_lstm(uX2, initial_state=decoder_states_inputs)
    decoder_states = [state_h, state_c]

    l2 = decoder_dense(l2)
    decoder_model = Model([uX2] + decoder_states_inputs, [l2] + decoder_states)

    #y = decoder_model.predict([np.zeros((1,1,1))]+[np.zeros((1,200)),np.zeros((1,200))])
    #print(y[0].shape,y[1].shape,y[2].shape)
    #sys.exit(0)


    state = encode_model.predict(X_test)
    #print(X_test.shape)
    #print(state[0].shape,state[1].shape)
    #sys.exit(0)

    yhat_ = np.zeros((len(X_test),1,n))


    y_pred = np.zeros((len(X_test),Ty,n))
    for t in range(Ty):
        yhat, h, c = decoder_model.predict([yhat_] + state)

        #print(yhat.shape)
        #sys.exit(0)

        y_pred[:,t,:] = yhat[:,0,:]
        #output.append(yhat[:,0,:])
        state = [h, c]
        yhat_ = yhat

    #output = np.array(output)



    def plot_tst():
        ns0 = Tx+Ty

        for j,c in enumerate(mcolors.TABLEAU_COLORS.items()):
            xx = np.arange(ns0)
            plt.plot(xx[:Tx],X[j].flatten(),color=c[1],marker='o')
            plt.plot(xx[Tx:],Y[j].flatten(),color=c[1],marker='o')
            plt.plot(xx[Tx:],y_pred[j].flatten(),color=c[1],marker='^')

            if j>3:
                break
        plt.show()


    plot_tst()

    plt.scatter(y_pred.flatten(),Y_test.flatten())
    plt.show()




class Model0:
    def __init__(self,Tx,Ty):
        self.n = 1

        uX = Input(shape=(Tx,n))
        encoder = LSTM(n_a0,return_state=True)

    def fit(X,Y):
        pass

    def predict(X):
        pass





def f5():
    m = 10000
    Tx = 40
    Ty = 40
    n = 1

    X,Y = init_ds3(m,Tx,Ty)
    X_train,Y_train,X_test,Y_test = split_train_test(X,Y)
    print('======================= ds dims:',X.shape,Y.shape)

    n_a0 = 100
    n_a1 = 100

    uX = Input(shape=(Tx,n))
    encoder = LSTM(n_a0,return_state=True)

    l0, h, c = encoder(uX)

    #m_ = Model(inputs=uX,outputs=[l0,h,c])
    #y = m_.predict(np.ones((1,Tx,1)))

    uX2 = Input(shape=(1,n))
    decoder_lstm = LSTM(n_a1,return_sequences=True,
            return_state=True)

    out=uX2
    outs=[]
    for t in range(Ty):
        l_,h,c = decoder_lstm(out,initial_state=[h,c])
        out = Dense(1)(l_)
        outs.append(out)

    print(Y_train.shape)
    model = Model(inputs=[uX,uX2],outputs=outs)
    model.compile(loss='mse', optimizer='adam')
    YY = [Y_train[:,i:i+1,:] for i in range(Ty)]
    model.fit([X_train,np.zeros((len(X_train),1,n))],YY,epochs=10)


    
    y_pred = model.predict([X_test,np.zeros((len(X_test),1,n))])
    Y_pred = np.zeros((len(X_test),Ty,n))
    for t in range(Ty):
        Y_pred[:,t:t+1,:] = y_pred[t]

    y_pred = Y_pred

    

    def plot_tst():
        ns0 = Tx+Ty

        for j,c in enumerate(mcolors.TABLEAU_COLORS.items()):
            xx = np.arange(ns0)
            plt.plot(xx[:Tx],X[j].flatten(),color=c[1],marker='o')
            plt.plot(xx[Tx:],Y[j].flatten(),color=c[1],marker='o')
            plt.plot(xx[Tx:],y_pred[j].flatten(),color=c[1],marker='^')

            break

            if j>1:
                break
        plt.show()

    plot_tst()

    plt.scatter(y_pred.flatten(),Y_test.flatten())
    plt.show()


if __name__=='__main__':
    from tensorflow.compat.v1 import ConfigProto
    from tensorflow.compat.v1 import InteractiveSession
    config = ConfigProto()
    config.gpu_options.allow_growth = True
    session = InteractiveSession(config=config)

    f5()


