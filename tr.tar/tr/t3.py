import os,sys
from collections import Counter
from tensorflow.keras.layers import Bidirectional, Concatenate, Permute, Dot, Input, LSTM, Multiply,GRUCell,RNN,GRU
from tensorflow.keras.layers import RepeatVector, Dense, Activation, Lambda,TimeDistributed
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import load_model, Model, model_from_json
import tensorflow.keras.backend as K
from tensorflow import keras
import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

from datetime import datetime
from dateutil.relativedelta import relativedelta


#os.environ['TF2_BEHAVIOR'] = '1'



def split_train_test(X,Y,seed=42):
    idx_s = np.arange(X.shape[0])
    np.random.seed(seed)
    np.random.shuffle(idx_s)
    n = int(len(X)*0.8)
    idx_train = idx_s[:n]
    idx_test = idx_s[n:]
    
    X_train = X[idx_train]
    Y_train = Y[idx_train]
    X_test = X[idx_test]
    Y_test = Y[idx_test]

    return X_train,Y_train,X_test,Y_test


def init_ds0(m,Tx):
    np.random.seed(42)
    X,Y=[],[]
    X  = np.random.randint(0,100,size=(m,Tx))
    X = X.reshape((*X.shape,1))
    Y = X.sum(axis=1)

    return X,Y


def init_ds1(m,Tx):
    X  = np.random.randint(0,100,size=(m,Tx,3))
    Y = X.sum(axis=2)
    Y = np.reshape(Y,(*Y.shape,1))

    return X,Y


def init_ds2(m,Tx,Ty):

    ns0 = Tx+Ty
    xx = np.linspace(0,700*m,ns0*m)
    x = np.sin(xx*np.pi/180)

    X,Y=[],[]
    for i in range(m):
        x_ = x[i*ns0:(i+1)*ns0]
        X.append(x_[:Tx])
        Y.append(x_[Tx:])


    X = np.reshape(X,(*np.shape(X),1))
    Y = np.reshape(Y,(*np.shape(Y),1))


    def plot_tst():
        for j in range(5):
            xx = np.arange(ns0)
            plt.plot(xx[:Tx],X[j].flatten(),'o-')
            plt.plot(xx[Tx:],Y[j].flatten(),'o-')

        plt.show()

    #plot_tst()
    #sys.exit(0)
    return X,Y






def init_ds3(m,Tx,Ty):

    ns0 = Tx+Ty

    x = np.zeros(ns0*m)
    for f in [100,1200]:
        xx = np.linspace(0,f*5*m,ns0*m)
        x += np.sin(xx*np.pi/180)

    X,Y=[],[]
    for i in range(m):
        x_ = x[i*ns0:(i+1)*ns0]
        X.append(x_[:Tx])
        Y.append(x_[Tx:])


    X = np.reshape(X,(*np.shape(X),1))
    Y = np.reshape(Y,(*np.shape(Y),1))


    def plot_tst():
        for j in range(1):
            xx = np.arange(ns0)
            plt.plot(xx[:Tx],X[j].flatten(),'o-')
            plt.plot(xx[Tx:],Y[j].flatten(),'o-')

        plt.show()

    #plot_tst()
    #sys.exit(0)
    return X,Y
















def f0():
    m = 2000
    Tx = 5
    X,Y = init_ds0(m,Tx)
    X_train,Y_train,X_test,Y_test = split_train_test(X,Y)
    print('ds dims:',X.shape,Y.shape)



    uX = Input(shape=(Tx,1))
    n_a0 = 64
    n_a1 = 64
    l0 = LSTM(n_a0,return_sequences=False)(uX)
    l00 = RepeatVector(1)(l0)
    #l1 = LSTM(n_a1,return_sequences=False,input_shape=(Tx,1))(l00)
    l1 = LSTM(n_a1,return_sequences=False,input_shape=(1,1))(l00)
    l2 = Dense(1)(l1)


    model = Model(inputs=uX,outputs=l2)
    model.compile(loss='mse', optimizer='adam')

    model.fit(X_train,Y_train,epochs=300)

    y_pred = model.predict(X_test)


    plt.scatter(y_pred.flatten(),Y_test.flatten())
    plt.show()

def f1():
    m = 2000
    Tx = 20
    n = 3

    X,Y = init_ds1(m,Tx)
    X_train,Y_train,X_test,Y_test = split_train_test(X,Y)
    print('======================= ds dims:',X.shape,Y.shape)
    print('======================= ds dims:',X_train.shape,Y_train.shape)

    #X_ = X[0]
    #for i in range(20):
    #    print(X_[i,0],X_[i,1],X_[i,2],Y[0,i])

    Ty = Tx
    
    uX = Input(shape=(Tx,n))
    n_a0 = 64
    n_a1 = 64
    l0 = LSTM(n_a0,return_sequences=True)(uX)
    #l00 = RepeatVector(Tx)(l0)
    #l1 = LSTM(n_a1,return_sequences=True)(l00)

    l1 = TimeDistributed(Dense(1), input_shape=(Tx, n_a0))(l0)

    model = Model(inputs=uX,outputs=l1)
    #print(model.predict(X_test).shape)
    model.compile(loss='mse', optimizer='adam')

    model.fit(X_train,Y_train,epochs=200)
    y_pred = model.predict(X_test)



    def plot_tst():
        plt.scatter(y_pred.flatten(),Y_test.flatten())
        plt.show()

    plot_tst()
    

def f2():
    m = 2000
    Tx = 20
    Ty = 5
    n = 1

    X,Y = init_ds2(m,Tx,Ty)
    X_train,Y_train,X_test,Y_test = split_train_test(X,Y)
    print('======================= ds dims:',X.shape,Y.shape)

    uX = Input(shape=(Tx,n))

    n_a0 = 64
    n_a1 = 64

    l0, state_h, state_c = LSTM(n_a0,return_state=True)(uX)
    encoder_states = [state_h, state_c]

    l1 = Dense(100, activation='relu')(l0)
    l2 = Dense(Ty)(l1)

    model = Model(inputs=uX,outputs=l2)
    model.compile(loss='mse', optimizer='adam')



    #uX2 = Input(shape=(None,Ty))

    #l1,_,_ = LSTM(n_a1,return_sequences=True,return_state=True)(uX2,initial_state=encoder_states)
    #l2 = TimeDistributed(Dense(1), input_shape=(Ty, n_a1))(l1)

    #model = Model(inputs=[uX,uX2],outputs=l2)
    #model.compile(loss='mse', optimizer='adam')

    model.fit(X_train,Y_train[:,:,0],epochs=200)
    y_pred = model.predict(X_test)
    y_pred = y_pred.reshape((*y_pred.shape,1))


    def plot_tst():
        ns0 = Tx+Ty

        for j in range(5):
            xx = np.arange(ns0)
            plt.plot(xx[:Tx],X[j].flatten(),'o-')
            plt.plot(xx[Tx:],Y[j].flatten(),'o-')
            plt.plot(xx[Tx:],y_pred[j].flatten(),'o-')
        plt.show()


    plot_tst()


def f3():
    m = 10000
    Tx = 30
    Ty = 5
    n = 1

    X,Y = init_ds2(m,Tx,Ty)
    X_train,Y_train,X_test,Y_test = split_train_test(X,Y)
    print('======================= ds dims:',X.shape,Y.shape)

    n_a0 = 100
    n_a1 = 100

    uX = Input(shape=(Tx,n))
    encoder = LSTM(n_a0,return_state=True)

    l0, state_h, state_c = encoder(uX)
    encoder_states = [state_h, state_c]


    uX2 = Input(shape=(Ty,n))


    decoder_lstm = LSTM(n_a1,return_sequences=True,
            return_state=True)
    l1,dec_h,dec_c = decoder_lstm(uX2,initial_state=encoder_states)
    dec_state_out = [dec_h,dec_c]


    decoder_dense = TimeDistributed(Dense(1), input_shape=(Ty, n_a1))
    l2 = decoder_dense(l1)

    model = Model(inputs=[uX,uX2],outputs=l2)
    model.compile(loss='mse', optimizer='adam')
    


    dec_x_train = np.zeros((len(Y_train),Ty,n))
    dec_x_train[:,0,:] = np.copy(X_train[:,-1,:])
    dec_x_train[:,1:,:] = np.copy(Y_train[:,:-1,:])

    #model.fit([X_train,dec_x_train],Y_train,epochs=100)

    y_pred = model.predict([X_test,dec_x0])

    sys.exit(0)

    m0 = Model(inputs=[uX],outputs=encoder_states)
    m1 = Model(inputs=[uX2],outputs=l2)
    state = m0.predict(X_test)
    yhat,h_,c_ = m1.predict([yhat]+state)

    print(model.summary())


    #encode_model = Model(uX,encoder_states)

    #print(encode_model.summary())

    #decoder_state_input_h = Input(shape=(n_a1,))
    #decoder_state_input_c = Input(shape=(n_a1,))
    #decoder_states_inputs = [decoder_state_input_h, decoder_state_input_c]

    #decoder_outputs, state_h, state_c = decoder_lstm(uX2, initial_state=decoder_states_inputs)
    #decoder_states = [state_h, state_c]

    #decoder_outputs = decoder_dense(l2)
    #decoder_model = Model([uX2] + decoder_states_inputs, [decoder_outputs] + decoder_states)

    #state = infenc.predict(X_test)

    #yhat_ = np.zeros((1,1,1))
    #yhat, h, c = infdec.predict([yhat_] + state)

    #print(yhat)



    #output = []
    #for t in range(Ty):
    #    # predict next char
    #    yhat, h, c = infdec.predict([yhat_] + state)
    #    # store prediction
    #    output.append(yhat[0,0,:])
    #    # update state
    #    state = [h, c]
    #    # update target sequence
    #    yhat_ = yhat

    #output = array(output)



    #y_pred = model_inf.predict(X_test)
    y_pred = y_pred.reshape((*y_pred.shape,1))



    def plot_tst():
        ns0 = Tx+Ty

        for j in range(2):
            xx = np.arange(ns0)
            plt.plot(xx[:Tx],X[j].flatten(),'o-')
            plt.plot(xx[Tx:],Y[j].flatten(),'o-')
            plt.plot(xx[Tx:],y_pred[j].flatten(),'o-')
        plt.show()

    plot_tst()


def f4():
    n_epochs=100
    m = 2000
    Tx = 20
    Ty = 20
    n = 1

    X,Y = init_ds2(m,Tx,Ty)
    X_train,Y_train,X_test,Y_test = split_train_test(X,Y)
    print('======================= ds dims:',X.shape,Y.shape)

    n_a0 = 100
    n_a1 = 100

    uX = Input(shape=(None,n))
    encoder = LSTM(n_a0,return_state=True)

    l0, state_h, state_c = encoder(uX)
    encoder_states = [state_h, state_c]




    uX2 = Input(shape=(None,n))

    decoder_lstm = LSTM(n_a1,return_sequences=True,
            return_state=True)
    l2,dec_h,dec_c = decoder_lstm(uX2,initial_state=encoder_states)

    decoder_dense = Dense(1)
    l2 = decoder_dense(l2)
    model = Model(inputs=[uX,uX2],outputs=l2)
    model.compile(loss='mse', optimizer='adam')


    #y = model.predict([np.zeros((1,1,1)),np.zeros((1,1,1))])
    #print(y.shape)
    #sys.exit(0)


    dec_x_train = np.zeros((len(Y_train),Ty,n))
    dec_x_train[:,0,:] = np.copy(X_train[:,-1,:])
    dec_x_train[:,1:,:] = np.copy(Y_train[:,:-1,:])

    model.fit([X_train,dec_x_train],Y_train,epochs=n_epochs)

    #y_pred = model.predict([X_test,dec_x0])

    encode_model = Model(uX,encoder_states)
    #y = encode_model.predict(np.zeros((1,1,1)))
    #print(y[0].shape,y[1].shape)
    #sys.exit(0)
    #print(encode_model.summary())

    decoder_state_input_h = Input(shape=(n_a1,))
    decoder_state_input_c = Input(shape=(n_a1,))
    decoder_states_inputs = [decoder_state_input_h, decoder_state_input_c]

    l2, state_h, state_c = decoder_lstm(uX2, initial_state=decoder_states_inputs)
    decoder_states = [state_h, state_c]

    l2 = decoder_dense(l2)
    decoder_model = Model([uX2] + decoder_states_inputs, [l2] + decoder_states)

    #y = decoder_model.predict([np.zeros((1,1,1))]+[np.zeros((1,200)),np.zeros((1,200))])
    #print(y[0].shape,y[1].shape,y[2].shape)
    #sys.exit(0)


    state = encode_model.predict(X_test)
    #print(X_test.shape)
    #print(state[0].shape,state[1].shape)
    #sys.exit(0)

    yhat_ = np.zeros((len(X_test),1,n))


    y_pred = np.zeros((len(X_test),Ty,n))
    for t in range(Ty):
        yhat, h, c = decoder_model.predict([yhat_] + state)

        #print(yhat.shape)
        #sys.exit(0)

        y_pred[:,t,:] = yhat[:,0,:]
        #output.append(yhat[:,0,:])
        state = [h, c]
        yhat_ = yhat

    #output = np.array(output)



    def plot_tst():
        ns0 = Tx+Ty

        for j,c in enumerate(mcolors.TABLEAU_COLORS.items()):
            xx = np.arange(ns0)
            plt.plot(xx[:Tx],X[j].flatten(),color=c[1],marker='o')
            plt.plot(xx[Tx:],Y[j].flatten(),color=c[1],marker='o')
            plt.plot(xx[Tx:],y_pred[j].flatten(),color=c[1],marker='^')

            if j>3:
                break
        plt.show()

    plot_tst()

    plt.scatter(y_pred.flatten(),Y_test.flatten())
    plt.show()



import utils_foreign

class Model1:
    def __init__(self):

        num_input_features = 1
        num_output_features = 1
        regulariser = None

        learning_rate = 0.01
        decay = 0
        optimiser = Adam(lr=learning_rate, decay=decay)


        encoder_inputs = Input(shape=(None, num_input_features))

        layers = [35,35]
        #layers = [35]

        #encoder_cells = []
        #for hidden_neurons in layers:
        #    encoder_cells.append(GRUCell(hidden_neurons))

        out0 = GRU(35,return_state=True,return_sequences=True)(encoder_inputs)
        encoder_outputs_and_states = GRU(35,return_state=True,return_sequences=True)(out0)

        #encoder = RNN(encoder_cells, return_state=True)
        #encoder_outputs_and_states = encoder(encoder_inputs)
        encoder_states = encoder_outputs_and_states[1:]




        decoder_inputs = Input(shape=(None, 1))

        decoder_cells = []
        for hidden_neurons in layers:
            decoder_cells.append(GRUCell(hidden_neurons))


        decoder = RNN(decoder_cells, return_sequences=True, return_state=True)
        decoder_outputs_and_states = decoder(decoder_inputs, initial_state=encoder_states)
        decoder_outputs = decoder_outputs_and_states[0]

        decoder_dense = Dense(num_output_features,activation='linear',
                kernel_regularizer=regulariser,bias_regularizer=regulariser)

        decoder_outputs = decoder_dense(decoder_outputs)

        model = Model(inputs=[encoder_inputs, decoder_inputs], outputs=decoder_outputs)
        model.compile(optimizer=optimiser, loss='mse')

        self.model = model




        encoder_predict_model = Model(encoder_inputs,encoder_states)
        decoder_states_inputs = []

        # Read layers backwards to fit the format of initial_state
        # For some reason, the states of the model are order backwards (state of the first layer at the end of the list)
        # If instead of a GRU you were using an LSTM Cell, you would have to append two Input tensors since the LSTM has 2 states.
        for hidden_neurons in layers[::-1]:
            # One state for GRU
            decoder_states_inputs.append(Input(shape=(hidden_neurons,)))

        decoder_outputs_and_states = decoder(
            decoder_inputs, initial_state=decoder_states_inputs)

        decoder_outputs = decoder_outputs_and_states[0]
        decoder_states = decoder_outputs_and_states[1:]

        decoder_outputs = decoder_dense(decoder_outputs)

        decoder_predict_model = Model(
                [decoder_inputs] + decoder_states_inputs,
                [decoder_outputs] + decoder_states)

    #def fit_and_save(self,name):
        #model = self.model

        input_sequence_length = 15 # Length of the sequence used by the encoder
        target_sequence_length = 15 # Length of the sequence predicted by the decoder
        num_steps_to_predict = 20 # Length to use when testing the model
        num_signals = 2 # The number of random sine waves the compose the signal. The more sine waves, the harder the problem.

        batch_size = 512
        #steps_per_epoch = 200 # batch_size * steps_per_epoch = total number of training examples
        steps_per_epoch = 10 # batch_size * steps_per_epoch = total number of training examples
        #epochs = 15
        epochs = 1

        train_data_generator = utils_foreign.random_sine(batch_size=batch_size,
                                           steps_per_epoch=steps_per_epoch,
                                           input_sequence_length=input_sequence_length,
                                           target_sequence_length=target_sequence_length,
                                           min_frequency=0.1, max_frequency=10,
                                           min_amplitude=0.1, max_amplitude=1,
                                           min_offset=-0.5, max_offset=0.5,
                                           num_signals=num_signals, seed=1969)



        print(model.summary())
        #sys.exit(0)


        model.fit_generator(train_data_generator, steps_per_epoch=steps_per_epoch, epochs=epochs)

        for w in model.optimizer.weights:
            print(w.name)

        #name='dddddd'
        #model.save_weights(name+'.h5',save_weights_only=True)


        sys.exit(0)



    #def load_and_pred(self,name):

        def predict(x, encoder_predict_model, decoder_predict_model, num_steps_to_predict):
            """Predict time series with encoder-decoder.
            
            Uses the encoder and decoder models previously trained to predict the next
            num_steps_to_predict values of the time series.
            
            Arguments
            ---------
            x: input time series of shape (batch_size, input_sequence_length, input_dimension).
            encoder_predict_model: The Keras encoder model.
            decoder_predict_model: The Keras decoder model.
            num_steps_to_predict: The number of steps in the future to predict
            
            Returns
            -------
            y_predicted: output time series for shape (batch_size, target_sequence_length,
                ouput_dimension)
            """
            y_predicted = []

            # Encode the values as a state vector
            states = encoder_predict_model.predict(x)

            # The states must be a list
            if not isinstance(states, list):
                states = [states]

            # Generate first value of the decoder input sequence
            decoder_input = np.zeros((x.shape[0], 1, 1))


            for _ in range(num_steps_to_predict):
                outputs_and_states = decoder_predict_model.predict(
                [decoder_input] + states, batch_size=batch_size)
                output = outputs_and_states[0]
                states = outputs_and_states[1:]

                # add predicted value
                y_predicted.append(output)

            return np.concatenate(y_predicted, axis=1)


        test_data_generator = utils_foreign.random_sine(batch_size=1000,
                                          steps_per_epoch=steps_per_epoch,
                                          input_sequence_length=input_sequence_length,
                                          target_sequence_length=target_sequence_length,
                                          min_frequency=0.1, max_frequency=10,
                                          min_amplitude=0.1, max_amplitude=1,
                                          min_offset=-0.5, max_offset=0.5,
                                          num_signals=num_signals, seed=2000)

        (x_test, _), y_test = next(test_data_generator)



        y_test_predicted = predict(x_test, encoder_predict_model, decoder_predict_model, num_steps_to_predict)

        # Select 10 random examples to plot
        indices = np.random.choice(range(x_test.shape[0]), replace=False, size=10)


        for index in indices:
            utils_foreign.plot_prediction(x_test[index, :, :], y_test[index, :, :], y_test_predicted[index, :, :])



class Model0:
    def __init__(self,n_a0,n_a1,Tx,Ty,nepochs):
        n = 1
        self.n = n
        self.Tx = Tx
        self.Ty = Ty
        self.nepochs = nepochs
        

        uX = Input(shape=(Tx,n))
        encoder = LSTM(n_a0,return_state=True)

        l0, h, c = encoder(uX)

        uX2 = Input(shape=(1,n))
        decoder_lstm = LSTM(n_a1,return_sequences=True,
                return_state=True)

        out=uX2
        outs=[]
        for t in range(Ty):
            l_,h,c = decoder_lstm(out,initial_state=[h,c])
            out = Dense(1)(l_)
            outs.append(out)

        model = Model(inputs=[uX,uX2],outputs=outs)
        model.compile(loss='mse', optimizer='adam')
        self.model = model





    def fit(self,X,Y,**kwargs):
        model = self.model
        Ty = self.Ty
        n = self.n
        nepochs = self.nepochs

        YY = [Y[:,i:i+1,:] for i in range(Ty)]

        X_test,Y_test = kwargs['validation_data']
        X0_test = np.zeros((len(X_test),1,n))
        Y_test = [Y_test[:,i:i+1,:] for i in range(Y_test.shape[1])]

        model.fit([X,np.zeros((len(X),1,n))],YY,epochs=nepochs,\
                validation_data=([X_test,X0_test],Y_test),callbacks=kwargs['callbacks'])
        #model.fit([X,np.zeros((len(X),1,n))],YY,epochs=nepochs)


    def predict(self,X):
        n = self.n
        Ty = self.Ty
        model = self.model

        y_pred = model.predict([X,np.zeros((len(X),1,n))])
        Y_pred = np.zeros((len(X),Ty,n))
        for t in range(Ty):
            Y_pred[:,t:t+1,:] = y_pred[t]

        y_pred = Y_pred

        return y_pred

    def save(self,name='model0'):
        model = self.model

        mj = model.to_json()
        with open(name+'.json','wb') as file:
            file.write(mj.encode('utf-8'))

        model.save_weights(name+'.h5')

    def load_model(self,name):
        with open(name+'.json','rb') as file:
            a = file.read().decode('utf-8')
        self.model = model_from_json(a)

    def load_weights(self,name='model0'):
        self.model.load_weights(name+'.h5')





def f55():
    m1 = Model1()
    #m1.fit_and_save('model1')


def f5(is_load,fn_y_pred):
    m = 10000
    Tx = 40
    Ty = 40
    n = 1

    X,Y = init_ds3(m,Tx,Ty)
    X_train,Y_train,X_test,Y_test = split_train_test(X,Y)
    print('======================= ds dims:',X.shape,Y.shape)

    n_a0 = 100
    n_a1 = 100



    if not is_load:
        m0 = Model0(n_a0,n_a1,Tx,Ty)
        m0.fit(X_train,Y_train)
        y_pred = m0.predict(X_test)

        np.save('m0_y_pred.npy',y_pred,allow_pickle=False)
    else:
        y_pred = np.load(fn_y_pred,allow_pickle=False)

        

    def plot_tst():
        ns0 = Tx+Ty

        for j in [2]:
            c = list(mcolors.TABLEAU_COLORS.items())[j]
            xx = np.arange(ns0)
            plt.plot(xx[:Tx],X[j].flatten(),color=c[1],marker='o')
            plt.plot(xx[Tx:],Y[j].flatten(),color=c[1],marker='o')
            plt.plot(xx[Tx:],y_pred[j].flatten(),color=c[1],marker='^')

        plt.show()

    plot_tst()

    plt.scatter(y_pred.flatten(),Y_test.flatten())
    plt.show()


def check_delta(df):
    df = df.copy(deep=True)
    df['id'] = np.arange(df.shape[0])
    df2 = df.iloc[1:,:].copy(deep=True)
    df2.id = np.arange(df2.shape[0]) 
    df02 = pd.merge(df.iloc[:-1,:],df2,how='inner',on='id')
    df02['dt'] = df02.t_y-df02.t_x
    print(Counter(df02.dt))


def plot_sm(df):
    df = df.iloc[:1000,:]
    xs = [t.strftime('%Y-%m-%d %H:%M:%S') for t in df.t]
    x = np.arange(0,len(xs),1)
    y = df.v
    ax = plt.gca()
    ax.set_xticks(x[::40])
    ax.set_xticklabels(xs[::40])
    plt.setp(ax.get_xticklabels(),rotation=90)
    ax.plot(x,y)
    plt.tight_layout()

    plt.show()



def xy(v):
    xx0,xx1 = [],[]

    mult = 100
    for i in range(0,len(v)//mult):
        t0 = i*mult
        t1 = t0+800
        t2 = t1+200
        if t2>len(v):
            break
        xx0.append(v[t0:t1])
        xx1.append(v[t1:t2])

    xx0 = np.array(xx0)
    xx1 = np.array(xx1)

    xx0 = xx0.reshape((*xx0.shape,1))
    xx1 = xx1.reshape((*xx1.shape,1))

    return xx0[:-2],xx1[:-2],xx0[-2:],xx1[-2:]



def f_sales():
    logdir='logs/scalars/' + datetime.now().strftime('%Y%m%d-%H%M%S')
    tensorboard_callback = keras.callbacks.TensorBoard(log_dir=logdir)

    class LossHistory(keras.callbacks.Callback):
        def on_train_begin(self, logs={}):
            self.losses = []

        def on_batch_end(self, batch, logs={}):
            self.losses.append(logs.get('loss'))

    history = LossHistory()



    df = pd.read_csv('test_data.csv')
    df.columns = ['t','v']

    df.t = pd.to_datetime(df.t,format='%Y-%m-%d %H:%M:%S')


    m0,m1 = df.t.iloc[0],df.t.iloc[-1] 
    #print(m0,m1)

    t = m0
    tt=[]
    while t<m1:
        tt.append(t)
        t+=relativedelta(minutes=30)
    #print(len(tt),df.shape)
    df_other = pd.DataFrame(tt,columns=['t'])
    df = pd.merge(df_other,df,how='left',on='t').fillna(0)

    #plot_sm(df)
    X_train,Y_train,X_test,Y_test = xy(df.v.values)

    print(X_train.shape,Y_train.shape,X_test.shape,Y_test.shape)

    m = len(X_train)
    Tx = 800
    Ty = 200
    n = 1

    n_a0 = 500
    n_a1 = 500


    nepochs = 10

    m0 = Model0(n_a0,n_a1,Tx,Ty,nepochs)
    m0.fit(X_train,Y_train,validation_data=(X_test, Y_test),callbacks=[tensorboard_callback,history])
    m0.save('model0')
    y_pred = m0.predict(X_test)

    plt.plot(Y_test.flatten())
    plt.plot(y_pred.flatten())
    plt.show()

    

def f00(**kwargs):
    #print([str(i) for i in kwargs.items()])
    print(kwargs['a'])
    print(kwargs.keys())


if __name__=='__main__':


    #f00(a=10)
    #sys.exit(0)
    try:
        is_load=sys.argv[1]=='load'
        fn_y_pred = sys.argv[2]
    except:
        is_load = False
        fn_y_pred=None

    if not is_load:
        from tensorflow.compat.v1 import ConfigProto
        from tensorflow.compat.v1 import InteractiveSession
        config = ConfigProto()
        config.gpu_options.allow_growth = True
        session = InteractiveSession(config=config)

    #f5(is_load,fn_y_pred)
    #f_sales()
    f55()


